package college.students; public class Main { public static void main(String[] args){new Student("Rahul").display();} }
