import java.util.Scanner;
public class Q06_Throw_Check_Age {
 static void checkAge(int age) { if(age<18) throw new IllegalArgumentException("Age must be at least 18."); System.out.println("Age accepted."); }
 public static void main(String[] args) { Scanner sc=new Scanner(System.in); try { System.out.print("Enter age: "); checkAge(sc.nextInt()); } catch(IllegalArgumentException e) { System.out.println("Error: "+e.getMessage()); } finally { sc.close(); } }
}
